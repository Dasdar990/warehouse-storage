
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T> = DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>> & T

type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }> & T


export const ActivityLog: typeof import("../components/ActivityLog.vue")['default']
export const ItemDetailCard: typeof import("../components/ItemDetailCard.vue")['default']
export const UnifiedSearchBar: typeof import("../components/UnifiedSearchBar.vue")['default']
export const AdminCategoryManager: typeof import("../components/admin/CategoryManager.vue")['default']
export const AdminUserManager: typeof import("../components/admin/UserManager.vue")['default']
export const DashboardAddItemForm: typeof import("../components/dashboard/AddItemForm.vue")['default']
export const DashboardFilterBar: typeof import("../components/dashboard/FilterBar.vue")['default']
export const DashboardItemTable: typeof import("../components/dashboard/ItemTable.vue")['default']
export const MapFreeformMap: typeof import("../components/map/FreeformMap.vue")['default']
export const MapEditor: typeof import("../components/map/MapEditor.vue")['default']
export const MapRackLevelsPanel: typeof import("../components/map/RackLevelsPanel.vue")['default']
export const MapRoomMapEditor: typeof import("../components/map/RoomMapEditor.vue")['default']
export const MapShelfDetailPanel: typeof import("../components/map/ShelfDetailPanel.vue")['default']
export const MapShelfMapEditor: typeof import("../components/map/ShelfMapEditor.vue")['default']
export const MapWarehouseMap: typeof import("../components/map/WarehouseMap.vue")['default']
export const MapZoneMapEditor: typeof import("../components/map/ZoneMapEditor.vue")['default']
export const NuxtWelcome: typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']
export const NuxtLayout: typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']
export const NuxtErrorBoundary: typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
export const ClientOnly: typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']
export const DevOnly: typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']
export const ServerPlaceholder: typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']
export const NuxtLink: typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']
export const NuxtLoadingIndicator: typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
export const NuxtTime: typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
export const NuxtRouteAnnouncer: typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
export const NuxtImg: typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']
export const NuxtPicture: typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']
export const NuxtPage: typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']
export const NoScript: typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']
export const Link: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']
export const Base: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']
export const Title: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']
export const Meta: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']
export const Style: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']
export const Head: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']
export const Html: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']
export const Body: typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']
export const NuxtIsland: typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']
export const LazyActivityLog: LazyComponent<typeof import("../components/ActivityLog.vue")['default']>
export const LazyItemDetailCard: LazyComponent<typeof import("../components/ItemDetailCard.vue")['default']>
export const LazyUnifiedSearchBar: LazyComponent<typeof import("../components/UnifiedSearchBar.vue")['default']>
export const LazyAdminCategoryManager: LazyComponent<typeof import("../components/admin/CategoryManager.vue")['default']>
export const LazyAdminUserManager: LazyComponent<typeof import("../components/admin/UserManager.vue")['default']>
export const LazyDashboardAddItemForm: LazyComponent<typeof import("../components/dashboard/AddItemForm.vue")['default']>
export const LazyDashboardFilterBar: LazyComponent<typeof import("../components/dashboard/FilterBar.vue")['default']>
export const LazyDashboardItemTable: LazyComponent<typeof import("../components/dashboard/ItemTable.vue")['default']>
export const LazyMapFreeformMap: LazyComponent<typeof import("../components/map/FreeformMap.vue")['default']>
export const LazyMapEditor: LazyComponent<typeof import("../components/map/MapEditor.vue")['default']>
export const LazyMapRackLevelsPanel: LazyComponent<typeof import("../components/map/RackLevelsPanel.vue")['default']>
export const LazyMapRoomMapEditor: LazyComponent<typeof import("../components/map/RoomMapEditor.vue")['default']>
export const LazyMapShelfDetailPanel: LazyComponent<typeof import("../components/map/ShelfDetailPanel.vue")['default']>
export const LazyMapShelfMapEditor: LazyComponent<typeof import("../components/map/ShelfMapEditor.vue")['default']>
export const LazyMapWarehouseMap: LazyComponent<typeof import("../components/map/WarehouseMap.vue")['default']>
export const LazyMapZoneMapEditor: LazyComponent<typeof import("../components/map/ZoneMapEditor.vue")['default']>
export const LazyNuxtWelcome: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/welcome.vue")['default']>
export const LazyNuxtLayout: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
export const LazyNuxtErrorBoundary: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
export const LazyClientOnly: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/client-only")['default']>
export const LazyDevOnly: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/dev-only")['default']>
export const LazyServerPlaceholder: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
export const LazyNuxtLink: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-link")['default']>
export const LazyNuxtLoadingIndicator: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
export const LazyNuxtTime: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
export const LazyNuxtRouteAnnouncer: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
export const LazyNuxtImg: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']>
export const LazyNuxtPicture: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']>
export const LazyNuxtPage: LazyComponent<typeof import("../node_modules/nuxt/dist/pages/runtime/page")['default']>
export const LazyNoScript: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['NoScript']>
export const LazyLink: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Link']>
export const LazyBase: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Base']>
export const LazyTitle: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Title']>
export const LazyMeta: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Meta']>
export const LazyStyle: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Style']>
export const LazyHead: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Head']>
export const LazyHtml: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Html']>
export const LazyBody: LazyComponent<typeof import("../node_modules/nuxt/dist/head/runtime/components")['Body']>
export const LazyNuxtIsland: LazyComponent<typeof import("../node_modules/nuxt/dist/app/components/nuxt-island")['default']>

export const componentNames: string[]
