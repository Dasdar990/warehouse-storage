
import type { DefineComponent, SlotsType } from 'vue'
type IslandComponent<T> = DefineComponent<{}, {refresh: () => Promise<void>}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, SlotsType<{ fallback: { error: unknown } }>> & T

type HydrationStrategies = {
  hydrateOnVisible?: IntersectionObserverInit | true
  hydrateOnIdle?: number | true
  hydrateOnInteraction?: keyof HTMLElementEventMap | Array<keyof HTMLElementEventMap> | true
  hydrateOnMediaQuery?: string
  hydrateAfter?: number
  hydrateWhen?: boolean
  hydrateNever?: true
}
type LazyComponent<T> = DefineComponent<HydrationStrategies, {}, {}, {}, {}, {}, {}, { hydrated: () => void }> & T

interface _GlobalComponents {
  ActivityLog: typeof import("../../components/ActivityLog.vue")['default']
  ItemDetailCard: typeof import("../../components/ItemDetailCard.vue")['default']
  UnifiedSearchBar: typeof import("../../components/UnifiedSearchBar.vue")['default']
  AdminCategoryManager: typeof import("../../components/admin/CategoryManager.vue")['default']
  AdminUserManager: typeof import("../../components/admin/UserManager.vue")['default']
  DashboardAddItemForm: typeof import("../../components/dashboard/AddItemForm.vue")['default']
  DashboardFilterBar: typeof import("../../components/dashboard/FilterBar.vue")['default']
  DashboardItemTable: typeof import("../../components/dashboard/ItemTable.vue")['default']
  MapFreeformMap: typeof import("../../components/map/FreeformMap.vue")['default']
  MapEditor: typeof import("../../components/map/MapEditor.vue")['default']
  MapRackLevelsPanel: typeof import("../../components/map/RackLevelsPanel.vue")['default']
  MapRoomMapEditor: typeof import("../../components/map/RoomMapEditor.vue")['default']
  MapShelfDetailPanel: typeof import("../../components/map/ShelfDetailPanel.vue")['default']
  MapShelfMapEditor: typeof import("../../components/map/ShelfMapEditor.vue")['default']
  MapWarehouseMap: typeof import("../../components/map/WarehouseMap.vue")['default']
  MapZoneMapEditor: typeof import("../../components/map/ZoneMapEditor.vue")['default']
  NuxtWelcome: typeof import("../../node_modules/nuxt/dist/app/components/welcome.vue")['default']
  NuxtLayout: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-layout")['default']
  NuxtErrorBoundary: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']
  ClientOnly: typeof import("../../node_modules/nuxt/dist/app/components/client-only")['default']
  DevOnly: typeof import("../../node_modules/nuxt/dist/app/components/dev-only")['default']
  ServerPlaceholder: typeof import("../../node_modules/nuxt/dist/app/components/server-placeholder")['default']
  NuxtLink: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-link")['default']
  NuxtLoadingIndicator: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']
  NuxtTime: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']
  NuxtRouteAnnouncer: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']
  NuxtImg: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']
  NuxtPicture: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']
  NuxtPage: typeof import("../../node_modules/nuxt/dist/pages/runtime/page")['default']
  NoScript: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['NoScript']
  Link: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Link']
  Base: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Base']
  Title: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Title']
  Meta: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Meta']
  Style: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Style']
  Head: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Head']
  Html: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Html']
  Body: typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Body']
  NuxtIsland: typeof import("../../node_modules/nuxt/dist/app/components/nuxt-island")['default']
  LazyActivityLog: LazyComponent<typeof import("../../components/ActivityLog.vue")['default']>
  LazyItemDetailCard: LazyComponent<typeof import("../../components/ItemDetailCard.vue")['default']>
  LazyUnifiedSearchBar: LazyComponent<typeof import("../../components/UnifiedSearchBar.vue")['default']>
  LazyAdminCategoryManager: LazyComponent<typeof import("../../components/admin/CategoryManager.vue")['default']>
  LazyAdminUserManager: LazyComponent<typeof import("../../components/admin/UserManager.vue")['default']>
  LazyDashboardAddItemForm: LazyComponent<typeof import("../../components/dashboard/AddItemForm.vue")['default']>
  LazyDashboardFilterBar: LazyComponent<typeof import("../../components/dashboard/FilterBar.vue")['default']>
  LazyDashboardItemTable: LazyComponent<typeof import("../../components/dashboard/ItemTable.vue")['default']>
  LazyMapFreeformMap: LazyComponent<typeof import("../../components/map/FreeformMap.vue")['default']>
  LazyMapEditor: LazyComponent<typeof import("../../components/map/MapEditor.vue")['default']>
  LazyMapRackLevelsPanel: LazyComponent<typeof import("../../components/map/RackLevelsPanel.vue")['default']>
  LazyMapRoomMapEditor: LazyComponent<typeof import("../../components/map/RoomMapEditor.vue")['default']>
  LazyMapShelfDetailPanel: LazyComponent<typeof import("../../components/map/ShelfDetailPanel.vue")['default']>
  LazyMapShelfMapEditor: LazyComponent<typeof import("../../components/map/ShelfMapEditor.vue")['default']>
  LazyMapWarehouseMap: LazyComponent<typeof import("../../components/map/WarehouseMap.vue")['default']>
  LazyMapZoneMapEditor: LazyComponent<typeof import("../../components/map/ZoneMapEditor.vue")['default']>
  LazyNuxtWelcome: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/welcome.vue")['default']>
  LazyNuxtLayout: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-layout")['default']>
  LazyNuxtErrorBoundary: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-error-boundary.vue")['default']>
  LazyClientOnly: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/client-only")['default']>
  LazyDevOnly: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/dev-only")['default']>
  LazyServerPlaceholder: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/server-placeholder")['default']>
  LazyNuxtLink: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-link")['default']>
  LazyNuxtLoadingIndicator: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-loading-indicator")['default']>
  LazyNuxtTime: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-time.vue")['default']>
  LazyNuxtRouteAnnouncer: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-route-announcer")['default']>
  LazyNuxtImg: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtImg']>
  LazyNuxtPicture: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-stubs")['NuxtPicture']>
  LazyNuxtPage: LazyComponent<typeof import("../../node_modules/nuxt/dist/pages/runtime/page")['default']>
  LazyNoScript: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['NoScript']>
  LazyLink: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Link']>
  LazyBase: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Base']>
  LazyTitle: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Title']>
  LazyMeta: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Meta']>
  LazyStyle: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Style']>
  LazyHead: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Head']>
  LazyHtml: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Html']>
  LazyBody: LazyComponent<typeof import("../../node_modules/nuxt/dist/head/runtime/components")['Body']>
  LazyNuxtIsland: LazyComponent<typeof import("../../node_modules/nuxt/dist/app/components/nuxt-island")['default']>
}

declare module 'vue' {
  export interface GlobalComponents extends _GlobalComponents { }
}

export {}
